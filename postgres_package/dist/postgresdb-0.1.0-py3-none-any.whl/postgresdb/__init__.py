from postgresdb.postgresdb import PostgresDB

"""
Importações:

1. Importa a classe PostgressDB
"""
